import {COLORS} from './core.mjs';
export function createView(canvas){
 const T=THREE;if(T.ColorManagement)T.ColorManagement.legacyMode=false;const scene=new T.Scene();scene.background=new T.Color('#9edfee');scene.fog=new T.Fog('#9edfee',30,90);
 const renderer=new T.WebGLRenderer({canvas,antialias:true,alpha:false,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.6));renderer.outputEncoding=T.sRGBEncoding;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1;renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;
 const camera=new T.PerspectiveCamera(43,1,.1,140);const mats=new Map(),geos=new Map();
 function material(c,rough=.48,metal=0){let key=c+':'+rough+':'+metal;if(!mats.has(key))mats.set(key,new T.MeshStandardMaterial({color:c,roughness:rough,metalness:metal}));return mats.get(key);}
 function mesh(g,m,p,x=0,y=0,z=0){let o=new T.Mesh(g,m);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;p.add(o);return o;}
 function ball(p,x,y,z,sx,sy,sz,c){let k='ball';if(!geos.has(k))geos.set(k,new T.SphereGeometry(1,20,14));let m=mesh(geos.get(k),typeof c==='string'?material(c):c,p,x,y,z);m.scale.set(sx,sy,sz);return m;}
 function rounded(w,h,d,r=.08){let key=[w,h,d,r].join(':');if(geos.has(key))return geos.get(key);r=Math.min(r,w/3,h/3,d/3);let sh=new T.Shape(),x=-w/2+r,y=-h/2+r,ww=w-2*r,hh=h-2*r;sh.moveTo(x,y-r);sh.lineTo(x+ww,y-r);sh.quadraticCurveTo(x+ww+r,y-r,x+ww+r,y);sh.lineTo(x+ww+r,y+hh);sh.quadraticCurveTo(x+ww+r,y+hh+r,x+ww,y+hh+r);sh.lineTo(x,y+hh+r);sh.quadraticCurveTo(x-r,y+hh+r,x-r,y+hh);sh.lineTo(x-r,y);sh.quadraticCurveTo(x-r,y-r,x,y-r);let g=new T.ExtrudeGeometry(sh,{depth:d-2*r,bevelEnabled:true,bevelSize:r*.5,bevelThickness:r,bevelSegments:2,steps:1,curveSegments:3});g.translate(0,0,-d/2+r);geos.set(key,g);return g;}
 function box(p,x,y,z,w,h,d,c,r=.06){return mesh(rounded(w,h,d,r),typeof c==='string'?material(c):c,p,x,y,z);}
 function rod(p,a,b,r,c){let va=new T.Vector3(...a),vb=new T.Vector3(...b),delta=vb.clone().sub(va);let g=new T.CylinderGeometry(r,r,delta.length(),10);let o=mesh(g,typeof c==='string'?material(c):c,p,...va.clone().add(vb).multiplyScalar(.5).toArray());o.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),delta.normalize());return o;}
 function ring(p,x,y,z,r,t,c){return mesh(new T.TorusGeometry(r,t,8,40),material(c,.3),p,x,y,z);}
 function label(p,text,x,y,z,w,h,bg='#073e4a',fg='#fff5cf'){let c=document.createElement('canvas');c.width=512;c.height=128;let ctx=c.getContext('2d');ctx.fillStyle=bg;ctx.fillRect(0,0,512,128);ctx.fillStyle=fg;ctx.font='900 56px Arial';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(text,256,66,480);let tex=new T.CanvasTexture(c);tex.encoding=T.sRGBEncoding;return mesh(new T.PlaneGeometry(w,h),new T.MeshBasicMaterial({map:tex}),p,x,y,z);}
 const hemi=new T.HemisphereLight('#e3faff','#45989c',.8);scene.add(hemi);let sun=new T.DirectionalLight('#fff0c9',1.8);sun.position.set(-10,20,12);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);Object.assign(sun.shadow.camera,{left:-14,right:14,top:16,bottom:-16,near:1,far:65});sun.shadow.bias=-.0006;sun.shadow.normalBias=.035;scene.add(sun);scene.add(new T.DirectionalLight('#b8ecff',.5));
 const set=new T.Group();scene.add(set);
 // Glazed pool basin: authored UV-free caustics, tiled coping and raised competition deck.
 box(set,0,-.65,-7,26,1.2,46,'#f7e9cf',.2);box(set,0,-.13,-7,14,.3,39,'#176877',.12);
 const water=new T.ShaderMaterial({uniforms:{time:{value:0},base:{value:new T.Color('#20b7c4')}},vertexShader:'varying vec3 v; uniform float time; void main(){v=position;vec3 p=position;p.z+=sin(p.x*1.3+time)*.025+cos(p.y*.9+time)*.02;gl_Position=projectionMatrix*modelViewMatrix*vec4(p,1.);}',fragmentShader:'varying vec3 v;uniform float time;uniform vec3 base;void main(){float a=sin(v.x*3.1+sin(v.y*2.2+time*.6));float b=cos(v.y*2.9+sin(v.x*2.1-time*.8));float ca=pow(max(0.,1.-abs(a+b)*1.7),7.);float waves=sin(v.y*.7+time)*.025;gl_FragColor=vec4(base+vec3(.13,.19,.16)*ca+waves,1.);}',side:T.DoubleSide});let waterMesh=mesh(new T.PlaneGeometry(13.5,38,28,50),water,set,0,.15,-7);waterMesh.rotation.x=-Math.PI/2;waterMesh.castShadow=false;
 for(let side of [-1,1]){box(set,side*7.25,.11,-7,.6,.35,39,'#fff8e9',.08);box(set,side*7.65,.05,-7,.15,.15,39,'#ecb17b',.03);for(let j=0;j<27;j++)box(set,side*7.25,.3,j*1.4-25,.57,.025,.025,'#a1c9c6',.005);}
 box(set,0,.24,2,8.8,.45,5.2,'#f5e9d1',.2);box(set,0,.48,2,8.45,.08,4.85,'#64c7bb',.03);
 for(let x=-4;x<=4;x+=.5)box(set,x,.528,2,.018,.008,4.7,'#b7ece0',.003);
 box(set,0,.55,.0,8.45,.08,.12,'#fff2b8',.02);
 for(let x of [-2.1,0,2.1]){let q=ring(set,x,.54,2,.6,.035,'#f9f4d5');q.rotation.x=-Math.PI/2;}
 // Wall rails and mechanical end stations.
 for(let s of [-1,1]){box(set,s*4.8,.35,-8,.2,.3,29,'#2b6f79');box(set,s*4.8,.52,-8,.075,.05,29,'#f7d191',.015);for(let z of [-20,-12,-4]){box(set,s*4.8,.1,z,.8,.5,.7,'#145160');}box(set,s*5.15,1.6,-21,1,3.2,1.5,'#f37d4d',.2);box(set,s*5.15,1.9,-20.2,.65,1.9,.2,'#fff2d4');for(let j=0;j<4;j++)ball(set,s*5.15,.95+j*.5,-20.05,.13,.13,.08,j%2?'#f7ce63':'#38aaae');}
 // Split spectator terraces, canvas awnings, planters and striping.
 const crowd=[];
 for(let s of [-1,1]){for(let row=0;row<3;row++){box(set,s*(9+row*.7),.4+row*.45,-9,1.4,.5,17,'#d6c8b7');for(let j=0;j<7;j++){let x=s*(9+row*.7),z=-15+j*2.2;box(set,x,.8+row*.45,z,.65,.12,.66,j%2?'#f6ad72':'#4faeab');let g=new T.Group();g.userData.animated=true;set.add(g);g.position.set(x,.9+row*.45,z);ball(g,0,.22,0,.21,.3,.19,['#f88363','#78c9b9','#e2b2e1','#edd17d'][(j+row)%4]);ball(g,0,.62,0,.18,.2,.18,['#e8ac79','#ae7559','#f0c89b'][j%3]);ball(g,0,.74,-.03,.19,.1,.18,'#403f43');g.rotation.y=s*Math.PI/2;crowd.push(g);}}
 for(let z of [-16,-8,0]){rod(set,[s*10.7,0,z],[s*10.7,5.4,z],.065,'#f1dfbc');box(set,s*10.1,5.4,z,4,.15,4.5,z===-8?'#f49567':'#54bdb9',.1);for(let k=0;k<5;k++)box(set,s*10.1,5.5,z-1.8+k*.85,3.9,.025,.3,'#fff0ce',.01);}}
 function palm(x,z,scale=1){let g=new T.Group();g.position.set(x,0,z);g.scale.setScalar(scale);set.add(g);let pts=[new T.Vector3(0,0,0),new T.Vector3(.1,2,0),new T.Vector3(.5,4,0),new T.Vector3(.75,5.4,0)];mesh(new T.TubeGeometry(new T.CatmullRomCurve3(pts),12,.17,7,false),material('#b97d51'),g);for(let j=0;j<7;j++){let a=j*Math.PI*2/7,shape=new T.Shape();shape.moveTo(0,0);shape.quadraticCurveTo(.45,1.1,0,2.7);shape.quadraticCurveTo(-.45,1.1,0,0);let leaf=mesh(new T.ShapeGeometry(shape,8),new T.MeshStandardMaterial({color:j%2?'#419d78':'#68b67c',side:T.DoubleSide,roughness:.85}),g,.75,5.4,0);leaf.rotation.set(-.6,a,.1);leaf.rotateZ(a);}}
 for(let s of [-1,1])for(let j=0;j<4;j++)palm(s*(13+j%2*2),-25+j*12,.8+(j%3)*.18);
 // Far architecture creates a full, coherent resort rather than an empty horizon.
 box(set,0,2.6,-29,23,5,2,'#ffe5c2',.4);for(let x=-10;x<=10;x+=2.5){box(set,x,2.4,-27.9,1.7,3.3,.1,'#68b4be');box(set,x,4.2,-27.8,2.2,.3,.5,'#f17d51');}box(set,0,5.2,-28.5,24,.35,4,'#f18451');label(set,'POSE  •  SPLASH',0,4.5,-27.35,9,1,'#f18451');
 // Rope flags and soft island silhouettes.
 for(let z of [-22,-12]){rod(set,[-13,6,z],[13,6,z],.025,'#fff3d2');for(let i=0;i<18;i++){let sh=new T.Shape();sh.moveTo(0,0);sh.lineTo(.65,0);sh.lineTo(.32,-.75);sh.closePath();let f=mesh(new T.ShapeGeometry(sh),new T.MeshStandardMaterial({color:i%2?'#ff9a62':'#fff2ca',side:T.DoubleSide}),set,-12+i*1.4,6,z);f.rotation.y=.2;}}
 
 // Resort craft pass: inset mosaic tiles, rescue gear, brass showers and striped umbrellas.
 const coral='#f88854',cream='#fff1cf',teal='#287f88';
 for(let side of [-1,1]){
  for(let j=0;j<25;j++){let zz=-23+j*1.35;for(let k=0;k<2;k++)box(set,side*(6.95+k*.25),.37,zz,.2,.035,.62,(j+k)%3===0?'#e5b865':'#d6eee3',.009);}
  for(let zz of [-17,-5,6]){let g=new T.Group();g.position.set(side*8.5,.3,zz);set.add(g);rod(g,[0,0,0],[0,3.6,0],.045,'#ddae69');let canopy=new T.Group();g.add(canopy);canopy.position.y=3.5;for(let n=0;n<12;n++){let a=n*Math.PI/6,b=(n+1)*Math.PI/6;let geom=new T.BufferGeometry();geom.setAttribute('position',new T.Float32BufferAttribute([0,.45,0,Math.cos(a)*1.65,0,Math.sin(a)*1.65,Math.cos(b)*1.65,0,Math.sin(b)*1.65],3));geom.computeVertexNormals();mesh(geom,new T.MeshStandardMaterial({color:n%2?cream:coral,side:T.DoubleSide,roughness:.8}),canopy);rod(canopy,[0,.43,0],[Math.cos(a)*1.65,0,Math.sin(a)*1.65],.013,'#e4c397');}ball(canopy,0,.48,0,.08,.12,.08,'#e9c476');box(g,0,.65,0,1.5,.12,.8,'#f3e2bb');for(let n of [-1,1])rod(g,[n*.55,0,0],[n*.55,.6,0],.05,teal);}
  for(let zz of [-9,1]){let rescue=ring(set,side*7.2,1.15,zz,.42,.12,coral);rescue.rotation.y=Math.PI/2;for(let i=0;i<4;i++){let a=i*Math.PI/2;ball(set,side*7.21,1.15+Math.sin(a)*.42,zz+Math.cos(a)*.42,.13,.11,.11,cream);}rod(set,[side*7.2,.3,zz-.65],[side*7.2,1.8,zz-.65],.035,teal);}
  for(let zz of [-18,-2]){rod(set,[side*6.6,.25,zz],[side*6.6,1.2,zz],.045,'#f3d09b');rod(set,[side*6.6,1.2,zz],[side*6.1,1.2,zz],.045,'#f3d09b');rod(set,[side*6.1,1.2,zz],[side*6.1,-.2,zz],.045,'#f3d09b');}
 }
 // A sculpted sun emblem and raised lettering frame the rear facade.
 let emblem=ring(set,0,6.4,-28,.65,.13,'#f9cb69');ball(set,0,6.4,-28,.48,.48,.12,'#fff0bb');for(let i=0;i<12;i++){let a=i*Math.PI/6;rod(set,[Math.cos(a)*.9,6.4+Math.sin(a)*.9,-28],[Math.cos(a)*1.1,6.4+Math.sin(a)*1.1,-28],.045,'#f9cb69');}
 for(let xx of [-6,-3,3,6]){let port=ring(set,xx,3,-27.65,.55,.1,'#fff2d0');ball(set,xx,3,-27.75,.46,.46,.06,'#4e9da9');rod(set,[xx-.4,3,-27.56],[xx+.4,3,-27.56],.025,'#f5e2bf');rod(set,[xx,2.6,-27.56],[xx,3.4,-27.56],.025,'#f5e2bf');}
 // Animated fountain beads are instanced to avoid dozens of extra draw calls.
 const jets=new T.InstancedMesh(new T.SphereGeometry(.035,5,4),material('#ccf7ef',.18),72);scene.add(jets);jets.frustumCulled=false;const jetMatrix=new T.Object3D();
 const ripples=[];for(let i=0;i<7;i++){let rr=ring(scene,(i%2?1:-1)*5.9,.205,-17+i*3.2,.3,.012,'#9de8df');rr.rotation.x=-Math.PI/2;rr.material=rr.material.clone();rr.material.transparent=true;rr.material.opacity=.35;rr.castShadow=false;ripples.push(rr);}

 // Pool furniture and planting stay outside the competition lanes.
 for(const side of [-1,1])for(const z of [-14,-7,0,7]){
   const x=side*8.1;
   box(set,x,.42,z,.72,.12,1.65,'#fff1cf');
   box(set,x,.51,z,.61,.11,1.49,'#f39568');
   const back=box(set,x,.74,z-.78,.65,.12,.8,'#f39568');
   back.rotation.x=.55;
   for(const offset of [-.58,.58])box(set,x,.23,z+offset,.63,.28,.12,'#397e83');
   for(let stripe=0;stripe<4;stripe++)box(set,x,.577,z+.32+stripe*.09,.55,.016,.04,'#fff2d0');
   box(set,side*9,.32,z+1.05,.72,.58,.72,'#d9815f',.1);
   for(let leaf=0;leaf<6;leaf++){
     const a=leaf*Math.PI/3;
     const frond=ball(set,side*9+Math.sin(a)*.24,.81,z+1.05+Math.cos(a)*.24,.11,.43,.14,leaf%2?'#589f76':'#81bc7d');
     frond.rotation.set(.6,a,0,'YXZ');
   }
 }
 // Batch static set dressing by material; retain articulated objects separately.
set.updateMatrixWorld(true);const batches=new Map(),remove=[];set.traverse(o=>{if(!o.isMesh||o===waterMesh)return;let a=o;while(a&&a!==set){if(a.userData.animated)return;a=a.parent;}let key=o.material.uuid;if(!batches.has(key))batches.set(key,{m:o.material,parts:[]});let g=o.geometry.index?o.geometry.toNonIndexed():o.geometry.clone();g.applyMatrix4(o.matrixWorld);batches.get(key).parts.push(g);remove.push(o);});for(let o of remove)o.removeFromParent();for(let b of batches.values()){let g=new T.BufferGeometry();for(let attr of ['position','normal','uv']){let size=attr==='uv'?2:3,total=b.parts.reduce((n,p)=>n+p.attributes.position.count*size,0),data=new Float32Array(total),offset=0;for(let p of b.parts){let ar=p.attributes[attr]?.array;if(ar)data.set(ar,offset);offset+=p.attributes.position.count*size;}g.setAttribute(attr,new T.BufferAttribute(data,size));}let m=mesh(g,b.m,set);m.castShadow=false;b.parts.forEach(p=>p.dispose());}crowd.forEach(g=>g.traverse(o=>{if(o.isMesh)o.castShadow=false;}));
function person(color){let root=new T.Group(),body=new T.Group();root.add(body);let suit=new T.MeshStandardMaterial({color,roughness:.6}),skin=material('#e6ad80',.68),dark=material('#253d4b'),ivory=material('#fff4d5');
  box(body,0,1.48,0,.71,.84,.45,suit,.15);ball(body,0,1.13,0,.35,.19,.23,suit);box(body,0,1.49,.239,.028,.62,.024,'#f5e8c9',.005);box(body,.19,1.65,.245,.18,.16,.03,'#fff3bf',.02);box(body,.19,1.65,.266,.09,.035,.01,'#2c7b81',.003);box(body,0,1.1,.03,.69,.1,.46,'#365465',.025);box(body,0,1.1,.285,.15,.11,.03,'#f9d685',.015);
  for(let s of [-1,1]){let c=ball(body,s*.2,1.87,.07,.22,.1,.24,ivory);c.rotation.z=s*.3;}
  let head=new T.Group();head.position.set(0,2.22,0);body.add(head);ball(head,0,0,0,.38,.44,.34,skin);ball(head,0,-.23,.09,.28,.18,.26,skin);for(let s of [-1,1]){ball(head,s*.37,0,0,.09,.15,.085,skin);ball(head,s*.4,0,.035,.035,.075,.055,'#d18a6b');ball(head,s*.145,.04,.292,.09,.115,.035,ivory);ball(head,s*.14,.04,.328,.043,.061,.022,dark);ball(head,s*.128,.062,.347,.014,.02,.009,'#ffffff');let brow=box(head,s*.15,.18,.29,.17,.04,.05,'#4c3940',.012);brow.rotation.z=s*-.08;ball(head,s*.235,-.105,.29,.075,.04,.02,'#df8f79');}
  ball(head,0,-.065,.34,.075,.085,.07,skin);let smile=new T.CatmullRomCurve3([new T.Vector3(-.1,-.2,.32),new T.Vector3(0,-.23,.34),new T.Vector3(.1,-.2,.32)]);mesh(new T.TubeGeometry(smile,8,.014,6,false),dark,head);
  ball(head,0,.23,-.07,.39,.29,.33,'#4b3941');for(let i=0;i<7;i++){let lock=ball(head,-.29+i*.095,.3+Math.sin(i*.7)*.045,.19,.1,.18,.18,'#5b4143');lock.rotation.z=-.45;}
  let band=ring(head,0,.27,0,.37,.045,'#ffda84');band.rotation.x=Math.PI/2;for(let s of [-1,1]){let lens=ball(head,s*.15,.34,.28,.135,.09,.045,material('#43b6c3',.12,.45));ring(head,s*.15,.34,.3,.09,.025,'#fff1c5').scale.x=1.3;}box(head,0,.34,.32,.08,.03,.025,'#fff0c2',.005);
  // Raised seams, zipper pull and goggle hardware read in the close shots.
  box(body,0,1.71,.264,.07,.11,.028,'#f8c77c',.012);
  for(const side of [-1,1]){
    rod(body,[side*.29,1.24,.197],[side*.29,1.71,.197],.012,'#f9dfac');
    rod(body,[side*.09,1.24,.259],[side*.23,1.32,.25],.016,'#4e7780');
    box(head,side*.35,.28,.16,.065,.083,.08,'#d69355',.015);
    ball(head,side*.15-.035,.366,.32,.034,.015,.012,'#ddfbf8');
  }
  const arms=[],legs=[];for(let s of [-1,1]){let arm=new T.Group();arm.position.set(s*.4,1.76,0);body.add(arm);ball(arm,0,-.08,0,.18,.22,.2,suit);rod(arm,[0,-.08,0],[0,-.43,0],.135,suit);ball(arm,0,-.46,0,.125,.13,.13,skin);rod(arm,[0,-.43,0],[0,-.73,.025],.105,skin);box(arm,0,-.68,.015,.23,.1,.22,'#fff4d6',.03);ball(arm,0,-.83,.035,.125,.16,.08,skin);for(let i=0;i<4;i++)ball(arm,-.072+i*.048,-.94,.04,.026,.065,.04,skin);ball(arm,s*.13,-.8,.04,.055,.08,.055,skin);arms.push(arm);
   let leg=new T.Group();leg.position.set(s*.2,1.02,0);root.add(leg);rod(leg,[0,0,0],[0,-.42,0],.15,suit);ball(leg,0,-.43,0,.15,.15,.16,suit);rod(leg,[0,-.43,0],[0,-.78,0],.12,skin);box(leg,0,-.72,0,.25,.21,.25,'#fff2d8',.035);box(leg,0,-.65,.131,.25,.035,.016,'#4ba4a8',.004);box(leg,0,-.89,.09,.31,.23,.49,'#fff0d7',.07);box(leg,0,-.98,.1,.33,.07,.51,'#355267',.02);for(let k=0;k<3;k++)box(leg,0,-.8,.18+k*.06,.2,.018,.022,'#65929a',.005);legs.push(leg);}
  return {root,body,head,arms,legs,suit,pose:0};
 }
 const actor=person(COLORS[0]);scene.add(actor.root);actor.root.position.set(0,.55,2);
 // Friendly camera drone doubles as rescue lifeguard.
 const drone=new T.Group();scene.add(drone);box(drone,0,0,0,.7,.45,.48,'#fff0c9',.13);box(drone,0,0,.255,.48,.24,.04,'#174957',.06);for(let s of [-1,1]){ball(drone,s*.12,.02,.29,.045,.06,.02,'#7af2df');rod(drone,[s*.28,.1,0],[s*.6,.2,0],.045,'#f2a25c');let fan=ring(drone,s*.6,.2,0,.23,.035,'#e98d53');fan.rotation.x=Math.PI/2;box(drone,s*.6,.22,0,.42,.025,.06,'#29616e',.01);}let buoy=ring(drone,0,-.4,0,.5,.13,'#ffc365');buoy.rotation.x=Math.PI/2;buoy.visible=false;
 const trophy=new T.Group();scene.add(trophy);trophy.visible=false;let cup=mesh(new T.CylinderGeometry(.38,.17,.5,24),material('#ffc75c',.23,.65),trophy,0,.8,0);rod(trophy,[0,.3,0],[0,.6,0],.07,'#f9c260');box(trophy,0,.2,0,.55,.13,.45,'#214e5a');for(let s of [-1,1])ring(trophy,s*.32,.8,0,.21,.045,'#ffcf6c');
 let wall=null,wallHole=null,currentSpec=null,wallZ=-18,wallAlpha=1;
 const outlines=[
 [[-1.08,2.95],[1.08,2.95],[1.08,2.18],[.55,1.6],[.57,1.05],[.57,-.07],[-.57,-.07],[-.57,1.05],[-.55,1.6],[-1.08,2.18]],
 [[-.52,2.88],[.52,2.88],[.52,2.12],[1.47,2.12],[1.47,1.43],[.57,1.43],[.57,-.07],[-.57,-.07],[-.57,1.43],[-1.47,1.43],[-1.47,2.12],[-.52,2.12]],
 [[-.55,1.93],[.55,1.93],[.55,1.1],[.94,.85],[.94,-.07],[-.94,-.07],[-.94,.85],[-.55,1.1]]
 ];
 function disposeWall(){if(!wall)return;scene.remove(wall);wall.traverse(o=>{if(o.isMesh){o.geometry.dispose();if(o.material?.userData?.wall)o.material.dispose();}});wall=null;}
 function newWall(spec,level){disposeWall();currentSpec=spec;wall=new T.Group();wall.position.y=.55;scene.add(wall);wallHole=new T.Group();wall.add(wallHole);const outline=outlines[spec.pose].map(([x,y])=>[x+Math.sign(x)*.3,y]);let shape=new T.Shape();shape.moveTo(-4.6,-.2);shape.lineTo(4.6,-.2);shape.lineTo(4.6,3.7);shape.lineTo(-4.6,3.7);shape.closePath();let hole=new T.Path();outline.forEach(([x,y],i)=>i?hole.lineTo(x+spec.x,y):hole.moveTo(x+spec.x,y));hole.closePath();shape.holes.push(hole);let m=new T.MeshStandardMaterial({color:['#f6a45f','#55c9bb','#c3a1e7'][level%3],roughness:.32,metalness:.03,transparent:true});m.userData.wall=true;let geo=new T.ExtrudeGeometry(shape,{depth:.25,bevelEnabled:true,bevelThickness:.025,bevelSize:.025,bevelSegments:1,curveSegments:1});mesh(geo,m,wallHole);
  let borderPoints=outline.map(([x,y])=>new T.Vector3(x+spec.x,y,.3));borderPoints.push(borderPoints[0]);let edgeGeo=new T.TubeGeometry(new T.CatmullRomCurve3(borderPoints,false,'catmullrom',0),outline.length*3,.035,5,false);mesh(edgeGeo,material('#fff8dc',.4),wallHole);
  box(wallHole,0,3.65,.12,9.5,.18,.48,'#fff2d1');for(let s of [-1,1]){box(wallHole,s*4.62,1.75,.12,.16,4,.48,'#fff2d1');for(let y of [.2,1.1,2,2.9])ball(wallHole,s*4.62,y,.4,.055,.055,.03,'#dd9f60');}wallZ=-18;wallAlpha=1;return wall;
 }
 const fxGeo=new T.SphereGeometry(1,6,4),fx=[];function burst(x,y,z,color,n=35){for(let i=0;i<n;i++){let o=mesh(fxGeo,material(color,.3),scene,x,y,z);o.castShadow=false;o.scale.setScalar(.045+Math.random()*.06);fx.push({o,v:new T.Vector3((Math.random()-.5)*6,2+Math.random()*4,(Math.random()-.5)*5),life:1+Math.random()});}while(fx.length>110){scene.remove(fx.shift().o);}}
 let previousShot='', shotTime=0;
 let time=0,poseValue=0,actorX=0,hitTimer=0,splashTimer=0,cameraMode='home',introTime=0,theme=0;
 function animate(dt,{x=0,pose=0,z=-18,holeX=0,phase='home',level=0}={}){if(previousShot!==phase){previousShot=phase;shotTime=0;}shotTime+=dt;time+=dt;water.uniforms.time.value=time;for(let i=0;i<72;i++){let side=i<36?-1:1,u=((time*.38+(i%36)/36)%1);jetMatrix.position.set(side*(6.65-u*.75),.3+Math.sin(u*Math.PI)*1.2,-13+Math.floor(i%36/12)*6);jetMatrix.scale.setScalar(.8+Math.sin(u*Math.PI)*.6);jetMatrix.updateMatrix();jets.setMatrixAt(i,jetMatrix.matrix);}jets.instanceMatrix.needsUpdate=true;ripples.forEach((r,i)=>{let q=(time*.35+i*.17)%1;r.scale.setScalar(1+q*2.4);r.material.opacity=(1-q)*.3;});theme=level;cameraMode=phase;actorX=T.MathUtils.damp(actorX,x,12,dt);poseValue=T.MathUtils.damp(poseValue,pose,15,dt);actor.root.position.x=actorX;
  let tall=pose===0,star=pose===1,duck=pose===2;let targetBody=duck?-.8:0;actor.body.position.y=T.MathUtils.damp(actor.body.position.y,targetBody,16,dt);
  actor.arms.forEach((a,i)=>{let sign=i===0?-1:1;let angle=tall?sign*2.4:star?sign*1.57:sign*.25;a.rotation.z=T.MathUtils.damp(a.rotation.z,angle,16,dt);});actor.legs.forEach((l,i)=>{l.rotation.z=T.MathUtils.damp(l.rotation.z,duck?(i===0?-.55:.55):0,16,dt);l.scale.y=T.MathUtils.damp(l.scale.y,duck?.55:1,16,dt);l.position.y=T.MathUtils.damp(l.position.y,duck?.57:1.02,16,dt);});
  actor.head.rotation.z=Math.sin(time*1.9)*.025;actor.root.rotation.y=T.MathUtils.damp(actor.root.rotation.y,phase==='home'?-.24:0,6,dt);actor.root.position.y=.55+Math.sin(time*3)*.018;actor.root.position.z=2;actor.root.rotation.x=0;actor.root.rotation.z=0;
  if(hitTimer>0){hitTimer-=dt;actor.root.position.y+=Math.sin(Math.max(0,hitTimer)*9)*.09;}
  if(splashTimer>0){splashTimer-=dt;let t=2.5-splashTimer;if(t<.8){actor.root.position.z=2+t*5;actor.root.position.y=.55+Math.sin(t*4)*1.2-t*1.4;actor.root.rotation.x=-t*4;}else{actor.root.position.y=-.3+Math.min(1,(t-.8)/1.7)*.85;actor.root.position.z=6-(t-.8)*2.35;actor.root.rotation.z=Math.sin(t*12)*.12;}buoy.visible=true;drone.position.set(actorX,actor.root.position.y+2,actor.root.position.z);}else{buoy.visible=false;drone.position.set(5.6+Math.sin(time*.5)*.4,3.5+Math.sin(time*2)*.12,4+Math.cos(time*.4));}
  if(wall){wall.position.z=z;wallHole.position.x=holeX-(currentSpec?.x||0);wall.visible=phase==='run'||phase==='recover';if(z>2.5){wall.traverse(o=>{if(o.material?.userData?.wall)o.material.opacity=Math.max(0,1-(z-2.5)/3);});}}
  crowd.forEach((g,i)=>{g.position.y=.9+Math.floor(i%21/7)*.45+Math.max(0,Math.sin(time*2+i))*(hitTimer>0?.18:.025);});
  for(let i=fx.length-1;i>=0;i--){let f=fx[i];f.life-=dt;f.v.y-=7*dt;f.o.position.addScaledVector(f.v,dt);f.o.rotation.x+=dt*6;f.o.scale.multiplyScalar(Math.pow(.65,dt));if(f.life<=0){scene.remove(f.o);fx.splice(i,1);}}
  trophy.visible=phase==='win';trophy.position.set(.9,1.5+Math.sin(time*2)*.07,2.3);trophy.rotation.y=time*.7;
  let cp=phase==='home'?new T.Vector3(3.4+Math.sin(time*.2)*.3,3.7,10.8):phase==='win'?new T.Vector3(3.5,3.3,9):new T.Vector3(actorX*.45,8.5,20.5);const aim=phase==='home'?new T.Vector3(0,1.65,2):phase==='win'?new T.Vector3(0,1.5,2):new T.Vector3(actorX*.45,1,-4);
  const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(phase==='intro' && !reduced){
    const wave=Math.sin(Math.PI*T.MathUtils.clamp((shotTime-.08)/1.15,0,1));
    actor.arms[1].rotation.z+=wave*(.4+Math.sin(shotTime*23)*.25);
    actor.head.rotation.z-=wave*.17;
    cp.lerp(new T.Vector3(actorX+2.2,4,10.5),wave*.85);
    aim.lerp(new T.Vector3(actorX,1.9,2),wave*.85);
  }
  if(phase==='recover' && splashTimer>0 && !reduced){
    const sweep=Math.sin(Math.PI*T.MathUtils.clamp(shotTime/2.3,0,1));
    cp.lerp(new T.Vector3(actorX-3,5.4,14),sweep*.78);
    aim.lerp(new T.Vector3(actorX,1.5,actor.root.position.z),sweep*.8);
    if(shotTime>.9){actor.arms[0].rotation.z=-.6;actor.arms[1].rotation.z=2.15+Math.sin(shotTime*16)*.2;}
  }
  if(phase==='win'){
    const bow=Math.sin(Math.PI*T.MathUtils.clamp(shotTime/1.45,0,1));
    actor.root.rotation.x=bow*.33;
    actor.arms[0].rotation.z=-.65;
    actor.arms[1].rotation.z=2.13+Math.sin(time*12)*.15;
    trophy.position.x=actorX+.9;
    aim.x=actorX+.25;
    cp.x+=actorX;
  }
  camera.position.lerp(cp,1-Math.exp(-dt*5));
  camera.lookAt(aim);renderer.render(scene,camera);
 }
 camera.position.set(3.4,3.7,10.8);
 function resize(){let w=canvas.clientWidth,h=canvas.clientHeight;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();}
 resize();return {animate,newWall,resize,renderer,actor,scene,success(perfect){hitTimer=.8;burst(actorX,2,2,perfect?'#fff0a0':'#a8ffdd',40);},splash(){splashTimer=2.5;burst(actorX,.5,5,'#c4f8f4',55);},setSuit(i){actor.suit.color.set(COLORS[i]);},celebrate(color='#ffd76d'){burst(0,4,2,color,60);},disposeWall};
}




